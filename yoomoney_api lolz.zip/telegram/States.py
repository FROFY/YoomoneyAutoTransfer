from aiogram.dispatcher.filters.state import StatesGroup, State


class StatesBot(StatesGroup):
    add_redirect = State()
    add_client_id = State()
    get_code = State()
    token_add = State()
    token_delete = State()
    balance_checking = State()
